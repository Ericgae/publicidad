CREATE DATABASE IF NOT EXISTS `llantera`;

USE `llantera`;

DROP TABLE IF EXISTS `almacen`;

CREATE TABLE `almacen` (
  `idalmacen` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkempresa` smallint(6) NOT NULL,
  `nombrea` varchar(30) DEFAULT NULL,
  `direcciona` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idalmacen`),
  KEY `fkempresa` (`fkempresa`),
  CONSTRAINT `almacen_ibfk_1` FOREIGN KEY (`fkempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `almacen` VALUES("2","1","TODOKA ALLENDE","ALLENDE #343 NORTE");
INSERT INTO `almacen` VALUES("3","2","LOPEZ","2 DE AGOSTO NUMERO ");



DROP TABLE IF EXISTS `articulo`;

CREATE TABLE `articulo` (
  `idarticulo` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `codigo` varchar(30) DEFAULT NULL,
  `marca` varchar(30) DEFAULT NULL,
  `foto` longblob,
  `punitario` double DEFAULT NULL,
  `punitariod` double DEFAULT NULL,
  `punitariot` double DEFAULT NULL,
  `fkAlmacen` smallint(6) DEFAULT NULL,
  `fkTipo` smallint(6) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cantidad` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idarticulo`),
  KEY `fkTipo` (`fkTipo`),
  KEY `fkAlmacen` (`fkAlmacen`),
  CONSTRAINT `articulo_ibfk_2` FOREIGN KEY (`fkTipo`) REFERENCES `tipo` (`idtipo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `articulo_ibfk_3` FOREIGN KEY (`fkAlmacen`) REFERENCES `almacen` (`idalmacen`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `articulo` VALUES("9","15\"","205/55","PIRELLI","../../articulos/5.jpg","1","34","6683","2","1","CARGA MÃX: 615 KG","23");
INSERT INTO `articulo` VALUES("10","20\"","195/50 R15","BARUM","../../articulos/234.jpg","1238","345","6648","3","1","CARGA MÃX: 475 KG","9");
INSERT INTO `articulo` VALUES("11","20","223F34","PIRELLI","../../articulos/logo modificado temoc.jpg","234","4322","3245335","2","1","MUY BUENA","34");



DROP TABLE IF EXISTS `automovil`;

CREATE TABLE `automovil` (
  `idauto` smallint(6) NOT NULL AUTO_INCREMENT,
  `marca` varchar(30) DEFAULT NULL,
  `modelo` varchar(30) DEFAULT NULL,
  `color` varchar(30) DEFAULT NULL,
  `placas` varchar(30) DEFAULT NULL,
  `rodado` varchar(30) DEFAULT NULL,
  `fkCliente` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`idauto`),
  KEY `fkCliente` (`fkCliente`),
  CONSTRAINT `automovil_ibfk_1` FOREIGN KEY (`fkCliente`) REFERENCES `cliente` (`idcliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `automovil` VALUES("1","FORD","F150","CAFE","REF257U","20","4");
INSERT INTO `automovil` VALUES("2","NISSAN","ALTIMA","ROSA","4DGGJY","15","6");



DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `idcliente` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkPersona` smallint(6) DEFAULT NULL,
  `tipoc` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idcliente`),
  KEY `fkPersona` (`fkPersona`),
  CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`fkPersona`) REFERENCES `persona` (`idpersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `cliente` VALUES("4","5","cotizacion");
INSERT INTO `cliente` VALUES("5","7","cotizacion");
INSERT INTO `cliente` VALUES("6","8","servicio");
INSERT INTO `cliente` VALUES("7","9","servicio");



DROP TABLE IF EXISTS `cotizaciones_demo`;

CREATE TABLE `cotizaciones_demo` (
  `id_cotizacion` smallint(6) NOT NULL AUTO_INCREMENT,
  `numero_cotizacion` int(11) NOT NULL,
  `fecha_cotizacion` datetime NOT NULL,
  `tel1` varchar(9) NOT NULL,
  `nombre` varchar(75) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `condiciones` varchar(30) NOT NULL,
  `validez` varchar(20) NOT NULL,
  `entrega` varchar(20) NOT NULL,
  `estadop` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_cotizacion`),
  KEY `numero_cotizacion` (`numero_cotizacion`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `cotizaciones_demo` VALUES("6","1","2018-07-05 19:56:33","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("7","2","2018-07-05 19:59:10","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("8","3","2018-07-05 20:00:32","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("9","4","2018-07-05 20:03:57","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("10","5","2018-07-05 20:15:39","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("11","6","2018-07-05 20:16:18","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("12","7","2018-07-05 20:23:05","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("13","8","2018-07-05 20:34:08","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("14","9","2018-07-05 20:35:07","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("15","10","2018-07-06 22:30:35","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("16","11","2018-07-06 22:35:20","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("17","12","2018-07-06 22:36:14","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("18","18","2018-07-06 23:37:23","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("19","19","2018-07-07 00:27:53","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("20","20","2018-07-07 18:11:27","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("21","21","2018-07-07 19:01:54","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("22","22","2018-07-07 21:52:21","","","","","","","1");
INSERT INTO `cotizaciones_demo` VALUES("23","23","2018-07-07 22:13:48","2324342","JUAN PEDRO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("24","24","2018-07-07 22:15:25","232324","JUAN PEDRO","eric@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("25","25","2018-07-07 22:18:13","2324342","JUAN PEDRO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("26","26","2018-07-07 22:21:03","2324343","FELIX","pedrito@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("27","27","2018-07-07 22:23:27","34312","WEWE","pedro@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("28","28","2018-07-07 22:59:07","2324342","JUAN PEDRO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("29","29","2018-07-13 00:22:12","2324342","PERDO","pedro@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("30","30","2018-07-13 01:03:48","2324343","PERDO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("31","31","2018-07-13 01:09:05","2324342","JUAN PEDRO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("32","32","2018-07-13 01:09:39","2324342","JUAN PEDRO","pedro@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("33","33","2018-07-13 01:12:37","66856893","FELIX","pedrito@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("34","34","2018-07-13 01:14:39","2234561","juna camanei","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("35","35","2018-07-18 20:39:09","rer","undefined","pedro@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("36","36","2018-07-20 02:04:14","546456456","LEONARDO","eric@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("37","37","2018-07-21 20:03:36","2324342","lucio biorato","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("38","38","2018-07-21 20:20:59","2324342","lucio biorato","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("39","39","2018-07-21 20:23:23","2324342","lucio biorato","pedrito@hotmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("40","40","2018-07-21 20:24:21","2324342","eric  garcia escamilla","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("41","41","2018-07-21 22:38:33","2324343","lucio biorato","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("42","42","2018-07-26 00:50:49","2324342","JUAN PEDRO","espectroocho@gmail.com","Contado","15 dÃ­as","Inmediato","1");
INSERT INTO `cotizaciones_demo` VALUES("43","43","2018-08-03 19:54:28","jhfrrg","josesito","pedro@hotmail.com","Contado","15 dÃ­as","Inmediato","1");



DROP TABLE IF EXISTS `cotizaciones_demo2`;

CREATE TABLE `cotizaciones_demo2` (
  `id_cotizacion` smallint(6) NOT NULL AUTO_INCREMENT,
  `numero_cotizacion` int(11) DEFAULT NULL,
  `fecha_cotizacion` datetime DEFAULT NULL,
  `fkcliente` smallint(6) NOT NULL,
  `fkempleado` smallint(6) NOT NULL,
  `fkauto` smallint(6) NOT NULL,
  `condiciones` varchar(30) NOT NULL,
  `validez` varchar(20) NOT NULL,
  `entrega` varchar(20) NOT NULL,
  PRIMARY KEY (`id_cotizacion`),
  KEY `fkpersona` (`fkcliente`),
  KEY `fkempleado` (`fkempleado`),
  KEY `fkauto` (`fkauto`),
  KEY `numero_cotizacion` (`numero_cotizacion`),
  CONSTRAINT `cotizaciones_demo2_ibfk_1` FOREIGN KEY (`numero_cotizacion`) REFERENCES `detalle_cotizacion_demo2` (`numero_cotizacion`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cotizaciones_demo2_ibfk_2` FOREIGN KEY (`fkcliente`) REFERENCES `cliente` (`idcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cotizaciones_demo2_ibfk_3` FOREIGN KEY (`fkempleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cotizaciones_demo2_ibfk_4` FOREIGN KEY (`fkauto`) REFERENCES `automovil` (`idauto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `cotizaciones_demo2` VALUES("2","1","2018-07-28 22:05:09","4","1","1","Contado","15 dÃ­as","Inmediato");



DROP TABLE IF EXISTS `detalle_cotizacion_demo`;

CREATE TABLE `detalle_cotizacion_demo` (
  `id_detalle_cotizacion` smallint(6) NOT NULL AUTO_INCREMENT,
  `numero_cotizacion` int(11) NOT NULL,
  `id_producto` smallint(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_venta` double NOT NULL,
  PRIMARY KEY (`id_detalle_cotizacion`),
  KEY `id_producto` (`id_producto`),
  KEY `numero_cotizacion` (`numero_cotizacion`),
  CONSTRAINT `detalle_cotizacion_demo_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalle_cotizacion_demo_ibfk_2` FOREIGN KEY (`numero_cotizacion`) REFERENCES `cotizaciones_demo` (`numero_cotizacion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `detalle_cotizacion_demo2`;

CREATE TABLE `detalle_cotizacion_demo2` (
  `id_detalle_cotizacion` smallint(6) NOT NULL AUTO_INCREMENT,
  `numero_cotizacion` int(11) NOT NULL,
  `id_producto` smallint(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_venta` double NOT NULL,
  PRIMARY KEY (`id_detalle_cotizacion`),
  KEY `id_producto` (`id_producto`),
  KEY `numero_cotizacion` (`numero_cotizacion`),
  CONSTRAINT `detalle_cotizacion_demo2_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;

INSERT INTO `detalle_cotizacion_demo2` VALUES("25","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("26","1","9","56","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("27","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("28","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("29","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("30","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("31","1","9","678","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("32","1","9","1356","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("33","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("34","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("35","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("36","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("37","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("38","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("39","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("40","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("41","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("42","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("43","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("44","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("45","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("46","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("47","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("48","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("49","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("50","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("51","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("52","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("53","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("54","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("55","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("56","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("57","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("58","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("59","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("60","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("61","2","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("62","3","9","7","890");
INSERT INTO `detalle_cotizacion_demo2` VALUES("63","4","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("64","5","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("65","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("66","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("67","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("68","6","10","1","1238");
INSERT INTO `detalle_cotizacion_demo2` VALUES("69","6","10","1","1238");
INSERT INTO `detalle_cotizacion_demo2` VALUES("70","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("71","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("72","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("73","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("74","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("75","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("76","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("77","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("78","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("79","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("80","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("81","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("82","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("83","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("84","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("85","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("86","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("87","6","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("88","7","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("89","7","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("90","7","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("91","8","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("92","8","10","1","1238");
INSERT INTO `detalle_cotizacion_demo2` VALUES("93","9","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("94","9","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("95","9","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("96","10","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("97","10","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("98","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("99","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("100","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("101","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("102","1","9","1","1");
INSERT INTO `detalle_cotizacion_demo2` VALUES("103","1","11","1","234");
INSERT INTO `detalle_cotizacion_demo2` VALUES("104","1","9","1","1");



DROP TABLE IF EXISTS `direccion`;

CREATE TABLE `direccion` (
  `iddireccion` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkempresa` smallint(6) NOT NULL,
  `calle` varchar(30) DEFAULT NULL,
  `colonia` varchar(30) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `tel` int(11) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`iddireccion`),
  KEY `fkEmpresa` (`fkempresa`),
  CONSTRAINT `direccion_ibfk_1` FOREIGN KEY (`fkempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `direccion_ibfk_2` FOREIGN KEY (`fkempresa`) REFERENCES `empresa` (`idempresa`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `direccion` VALUES("2","1","1 NOVIEMBRE","2 DE AGOSTO","23","23232323","lopez@hotmail.com");
INSERT INTO `direccion` VALUES("3","2","SIEMPRE VIVA","LA LOMA","23","2147483647","ESPECTROOCHO@GMAIL.C");



DROP TABLE IF EXISTS `empleado`;

CREATE TABLE `empleado` (
  `idEmpleado` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkPersona` smallint(6) NOT NULL,
  `tipoE` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`idEmpleado`),
  KEY `fkPersona` (`fkPersona`),
  CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`fkPersona`) REFERENCES `persona` (`idpersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `empleado` VALUES("1","6","Administrador","angel","angel");
INSERT INTO `empleado` VALUES("2","10","Socio","socio1","socio1");



DROP TABLE IF EXISTS `empresa`;

CREATE TABLE `empresa` (
  `idempresa` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombree` varchar(30) DEFAULT NULL,
  `propietarioe` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idempresa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `empresa` VALUES("1","KODAK","ANGELE");
INSERT INTO `empresa` VALUES("2","NORTEÃ‘A","NO MAMES WEY");



DROP TABLE IF EXISTS `multipuntos`;

CREATE TABLE `multipuntos` (
  `idmulti` smallint(6) NOT NULL AUTO_INCREMENT,
  `nitrogeno` varchar(50) NOT NULL,
  `tipo_poliza` varchar(50) NOT NULL,
  `alineacion` varchar(50) NOT NULL,
  `balatas` varchar(30) DEFAULT NULL,
  `suspencion` varchar(30) DEFAULT NULL,
  `llantas` varchar(30) DEFAULT NULL,
  `baterias` varchar(30) DEFAULT NULL,
  `pulido_faro` varchar(30) DEFAULT NULL,
  `rotacion` varchar(30) DEFAULT NULL,
  `llanta_desecha` varchar(30) DEFAULT NULL,
  `especificacion` varchar(100) DEFAULT NULL,
  `fkcotiza` int(6) DEFAULT NULL,
  PRIMARY KEY (`idmulti`),
  KEY `fkVenta` (`fkcotiza`),
  CONSTRAINT `multipuntos_ibfk_1` FOREIGN KEY (`fkcotiza`) REFERENCES `cotizaciones_demo2` (`numero_cotizacion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `multipuntos` VALUES("6","","","","","","","","","","","vvggg\n","1");
INSERT INTO `multipuntos` VALUES("7","no","si","no","si","si","si","si","no","no","si","bbb","1");
INSERT INTO `multipuntos` VALUES("8","","","","","","","","","","","hhh","1");
INSERT INTO `multipuntos` VALUES("9","no","si","no","si","no","no","si","no","si","no","vvb","1");



DROP TABLE IF EXISTS `persona`;

CREATE TABLE `persona` (
  `idpersona` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `apeliidoP` varchar(30) DEFAULT NULL,
  `apellidoM` varchar(30) DEFAULT NULL,
  `tel` int(12) DEFAULT NULL,
  PRIMARY KEY (`idpersona`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `persona` VALUES("5","JUAN ","MARQUES","LOPEZ","2147483647");
INSERT INTO `persona` VALUES("6","LEONARDO","GARCIA","DIAZ","2147483647");
INSERT INTO `persona` VALUES("7","LUIS","GARCIA","MENDOZA","2147483647");
INSERT INTO `persona` VALUES("8","FELIX","ULLOA","LAGOS","2147483647");
INSERT INTO `persona` VALUES("9","DANNIEL","RODRIGUEZ","AGUILAR","2147483647");
INSERT INTO `persona` VALUES("10","MANUEL","ESCAMILLA","GRAJEDA","2147483647");



DROP TABLE IF EXISTS `promocion`;

CREATE TABLE `promocion` (
  `idpromo` smallint(6) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) DEFAULT NULL,
  `codigo` varchar(30) DEFAULT NULL,
  `fkArticulo` smallint(6) DEFAULT NULL,
  `estatus` varchar(30) DEFAULT NULL,
  `fechaInicio` date DEFAULT NULL,
  `fechaFin` date NOT NULL,
  PRIMARY KEY (`idpromo`),
  KEY `fkArticulo` (`fkArticulo`),
  CONSTRAINT `promocion_ibfk_1` FOREIGN KEY (`fkArticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `tecnico`;

CREATE TABLE `tecnico` (
  `idtecnico` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkPersona` smallint(6) NOT NULL,
  PRIMARY KEY (`idtecnico`),
  KEY `fkPersona` (`fkPersona`),
  CONSTRAINT `tecnico_ibfk_1` FOREIGN KEY (`fkPersona`) REFERENCES `persona` (`idpersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `tipo`;

CREATE TABLE `tipo` (
  `idtipo` smallint(6) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idtipo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tipo` VALUES("1","LLANTAS");
INSERT INTO `tipo` VALUES("2","rines");
INSERT INTO `tipo` VALUES("3","audio");



DROP TABLE IF EXISTS `tmp_cotizacion`;

CREATE TABLE `tmp_cotizacion` (
  `id_tmp` smallint(6) NOT NULL AUTO_INCREMENT,
  `id_producto` smallint(11) NOT NULL,
  `cantidad_tmp` int(11) NOT NULL,
  `precio_tmp` double(8,2) DEFAULT NULL,
  `session_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_tmp`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tmp_cotizacion_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `tmp_cotizacion2`;

CREATE TABLE `tmp_cotizacion2` (
  `id_tmp` smallint(6) NOT NULL AUTO_INCREMENT,
  `id_producto` smallint(11) NOT NULL,
  `cantidad_tmp` int(11) NOT NULL,
  `precio_tmp` double(8,2) DEFAULT NULL,
  `session_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_tmp`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tmp_cotizacion2_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

INSERT INTO `tmp_cotizacion2` VALUES("10","9","1","1.00","g9if3f51n80b68ebtjpae3mgd7");
INSERT INTO `tmp_cotizacion2` VALUES("11","9","3","1.00","g9if3f51n80b68ebtjpae3mgd7");
INSERT INTO `tmp_cotizacion2` VALUES("57","9","1","1.00","1hph1i91r706jkbupo0abqgoa6");
INSERT INTO `tmp_cotizacion2` VALUES("58","9","1","1.00","1hph1i91r706jkbupo0abqgoa6");
INSERT INTO `tmp_cotizacion2` VALUES("62","9","1","1.00","edk8lc13v5jjlv0ag5f4q15t33");
INSERT INTO `tmp_cotizacion2` VALUES("63","9","1","1.00","edk8lc13v5jjlv0ag5f4q15t33");
INSERT INTO `tmp_cotizacion2` VALUES("64","9","1","1.00","5a4d3dragjic820ckicokbbau6");
INSERT INTO `tmp_cotizacion2` VALUES("65","9","1","1.00","5a4d3dragjic820ckicokbbau6");



DROP TABLE IF EXISTS `user_demo`;

CREATE TABLE `user_demo` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `lastname` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(96) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `code` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `user_demo` VALUES("1","Obed","Alvarado","joaquinobed@gmail.com","2555","1","2014-04-11 00:00:00");



DROP TABLE IF EXISTS `vendedor`;

CREATE TABLE `vendedor` (
  `idvendedor` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkPersona` smallint(6) NOT NULL,
  PRIMARY KEY (`idvendedor`),
  KEY `fkPersona` (`fkPersona`),
  CONSTRAINT `vendedor_ibfk_1` FOREIGN KEY (`fkPersona`) REFERENCES `persona` (`idpersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `ventas`;

CREATE TABLE `ventas` (
  `idventas` smallint(6) NOT NULL AUTO_INCREMENT,
  `fkArticulo` smallint(6) DEFAULT NULL,
  `fkVendedor` smallint(6) DEFAULT NULL,
  `fkPromocion` smallint(6) DEFAULT NULL,
  `fkCliente` smallint(6) DEFAULT NULL,
  `cantidad` varchar(30) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` double DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `extras` varchar(30) DEFAULT NULL,
  `fkAuto` smallint(6) DEFAULT NULL,
  `fkTecninco` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`idventas`),
  KEY `fkArticulo` (`fkArticulo`),
  KEY `fkPromocion` (`fkPromocion`),
  KEY `fkCliente` (`fkCliente`),
  KEY `fkAuto` (`fkAuto`),
  KEY `fkVendedor` (`fkVendedor`),
  KEY `fkTecninco` (`fkTecninco`),
  CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`fkArticulo`) REFERENCES `articulo` (`idarticulo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_3` FOREIGN KEY (`fkPromocion`) REFERENCES `promocion` (`idpromo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_4` FOREIGN KEY (`fkCliente`) REFERENCES `cliente` (`idcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_5` FOREIGN KEY (`fkAuto`) REFERENCES `automovil` (`idauto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_6` FOREIGN KEY (`fkTecninco`) REFERENCES `tecnico` (`idtecnico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_7` FOREIGN KEY (`fkVendedor`) REFERENCES `vendedor` (`idvendedor`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ventas_ibfk_8` FOREIGN KEY (`fkTecninco`) REFERENCES `tecnico` (`idtecnico`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

